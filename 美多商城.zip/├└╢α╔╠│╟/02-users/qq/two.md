# OAuth2.0认证 {#oauth20认证}



1. 准备oauth\_callback回调页，用于扫码后接受Authorization Code

2. 通过Authorization Code获取Access Token
3. 通过Access Token获取OpenID



