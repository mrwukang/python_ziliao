#!/bin/bash
# cp /mnt/hgfs/Import/py41118/* -r ./
rm -f book.pdf
gitbook build --gitbook=2.6.7
gitbook pdf .
